package com.example.gpsmapapp;

// Imports de Android base
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.Toast;

// Imports de compatibilidad y AndroidX
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// Imports de Google Maps y Location Services
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;


// Implementamos OnMapReadyCallback para manejar el mapa
public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    // Constante para el código de solicitud de permiso
    private static final int LOCATION_REQUEST_CODE = 161;
    private GoogleMap map;
    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // El layout activity_main debe contener un MapView o SupportMapFragment
        setContentView(R.layout.activity_main);

        // 1. Inicializar el Fragmento del Mapa
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.mapView);
        mapFragment.getMapAsync(this);

        // 2. Inicializar el cliente de ubicación
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // 3. Verificar los permisos al iniciar
        checkLocationPermission();
    }

    // Método para verificar y solicitar permisos
    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Solicitar el permiso
            ActivityCompat.requestPermissions(this,
                    new String[] {Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_REQUEST_CODE);
        } else {
            // Permiso ya concedido, obtenemos la ubicación
            getCurrentLocation();
        }
    }

    // Método que se ejecuta cuando el mapa está listo
    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;

        // Habilitar la capa de punto azul de ubicación si tenemos permisos
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            map.setMyLocationEnabled(true);
            getCurrentLocation(); // Obtener la ubicación inmediatamente
        }

        // Opcional: Implementar la adición de marcadores al hacer click (Requisito de la pauta)
        map.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                map.addMarker(new MarkerOptions()
                        .position(latLng)
                        .title("Marcador Añadido"));
            }
        });
    }

    // Método para obtener la última ubicación conocida
    private void getCurrentLocation() {
        // Doble verificación de permisos (requerido por el linter de Android)
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());

                            // Mover la cámara del mapa a la ubicación actual y hacer zoom
                            map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15));

                            // Añadir un marcador de ubicación actual
                            map.addMarker(new MarkerOptions().position(currentLatLng).title("Ubicación Actual"));
                        }
                    }
                });
    }

    // Manejar el resultado de la solicitud de permisos
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permiso concedido
                getCurrentLocation();
            } else {
                // Permiso denegado
                Toast.makeText(this, "Permiso de ubicación denegado", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
